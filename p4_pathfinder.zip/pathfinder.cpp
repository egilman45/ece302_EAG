#include "image.h"
#include "deque.hpp"
#include <iostream>
#include <vector>

//Function Prototypes
bool inExplored(int, int);
bool checkEdge(int, Image<Pixel>);

//Define Vector to hold coordinates already searched
std::vector<std::vector<int>> explored;

int main(int argc, char *argv[])
{
  //Read the file 
  try {

    //frontier = FIFO queue
    //Deque<int> frontier;
    std::vector<std::vector<int>> frontier;

    //explored = empty set
    std::vector<int> currentSet;
    std::vector<int> temp;
    

    //Create Initial Condition State
    std::vector<int> redLocation;
    int red_count = 0;
    
    //Read the input file pixel information
    Image<Pixel> input = readFromFile(argv[1]); 

    int state = 0;
    bool success = false;

    while (success != true){
      std::cout << "Loop" << std::endl;

      switch (state){
        
        case 0:
        std::cout << "State 0" << std::endl;
        //Initial State

          //Find the Red Pixel 
          for (size_t row = 0; row < input.height(); row++) {
            for (size_t col = 0; col < input.width(); col++){
              if(input(row,col) == RED) {
                red_count++;
                if(red_count > 1){
                  //ERROR more than one starting point
                  return EXIT_FAILURE;
                }
                redLocation.push_back(row);
                redLocation.push_back(col);
                std::cout << "Initial Position: " << row << " " << col << std::endl;
              }
            }
          } 

          //Add Coordinates to Frontier
          frontier.push_back(redLocation);
          //frontier.pushFront(redLocation[0]);

          //Send Intial to Goal and Check if Start is Already Finish
          //Change States to Check for Success
          state = 1;

          break;

        case 1:
        std::cout << "State 1" << std::endl;
        //Checking for Success

        //If Frontier is Empty Return Failure
        if(frontier.empty() == true) {
          std::cout << "Frontier Empty" << std::endl;
           return EXIT_FAILURE;
        }
        
        std::cout << "Frontier: " << frontier[0][0] << " " << frontier[0][1] << std::endl;

        //Find the New Coordinates From The Frontier
        //Pop coordinates off frontier
        /*std::cout << "Frontier: " << std::endl;
        for (int i = 0; i < frontier.size(); i++) {
          for (int j = 0; j = frontier[i].size(); j++) {
            std::cout << frontier[i][j] << " " << frontier[i][j] << std::endl;
          }
        }*/
        currentSet.clear();
        currentSet.push_back(frontier[0][0]);
        currentSet.push_back(frontier[0][1]);
        std::cout << "Current Set: " << currentSet[0] << " " << currentSet[1] << std::endl;
        frontier.pop_back();
        //currentSet[1] = frontier.front();
        //frontier.popFront();

        //Add Coordinates to Explored
        //explored.push_back(currentSet[0]);
        for (int i = 0; i < explored.size(); i++) {
          if(currentSet == explored[i]){
            state = 2;
            break;
          }
        }
        
        explored.push_back(currentSet);

        //Use currentSet coordinates to see if the Coordinates are Solutions
        std::cout << "Checking Coordinates Against Edge" << std::endl;
        
        if((checkEdge(currentSet[0], input)==true) || (checkEdge(currentSet[1], input)==true)) {
          state = 3;
        } else {
          state = 2;
        }

        std::cout << "Changing State" << std::endl;

        break;

        case 2:
        std::cout << "State 2" << std::endl;
        //Unsuccessful Try, Assign Next Pixel
        
        std::cout << "Assigning Next Pixel" << std::endl;

        //std::cout << "Checking: " << currentSet[0] << " " << (currentSet[1]-1) << std::endl;
        //std::cout << "Result: " << (input(currentSet[0], (currentSet[1]-1))==WHITE) << std::endl;

        temp.clear();

        if((input(currentSet[0], (currentSet[1]-1))==WHITE) && 
          (inExplored((currentSet[0]), (currentSet[1]-1))==false)){
        //Check Previous Row for Black/White Space 
        std::cout << "Previous Row" << std::endl;
          temp.push_back(currentSet[0]);
          temp.push_back(currentSet[1]-1); 
          std::cout << "Sending to Frontier: " << temp[0] << " " << temp[1] << std::endl;
          frontier.clear();
          frontier.push_back(temp);
          state = 1;
          break;
          //frontier.pushFront(temp);
        } else if ((input(currentSet[0], (currentSet[1]+1))==WHITE) && 
          (inExplored((currentSet[0]), (currentSet[1]+1))==false)){
        //Check Next Row for Black/White Space
        std::cout << "Next Row" << std::endl;
          temp.push_back(currentSet[0]);
          temp.push_back(currentSet[1]+1); 
          std::cout << "Sending to Frontier: " << temp[0] << " " << temp[1] << std::endl;
          frontier.clear();
          frontier.push_back(temp);
          state = 1;
          break;
          //frontier.pushFront(temp);
        } else if ((input((currentSet[0]-1), (currentSet[1]))==WHITE) && 
          (inExplored((currentSet[0]-1), (currentSet[1]))==false)){
        //Check Previous Column for Black/White Space
        std::cout << "Previous Column" << std::endl;
          temp.push_back(currentSet[0]-1);
          temp.push_back(currentSet[1]);  
          std::cout << "Sending to Frontier: " << temp[0] << " " << temp[1] << std::endl;
          frontier.clear();
          frontier.push_back(temp);
          state = 1;
          break;
          //frontier.pushFront(temp);
        } else if ((input((currentSet[0]+1), (currentSet[1]))==WHITE) && 
          (inExplored(currentSet[0]+1, (currentSet[1]))==false)){
          //Check Next Column for Black/White Space
          std::cout << "Next Column" << std::endl;
          temp.push_back(currentSet[0]+1);
          temp.push_back(currentSet[1]);
          std::cout << "Sending to Frontier: " << temp[0] << " " << temp[1] << std::endl; 
          frontier.clear();
          frontier.push_back(temp);
          state = 1;
          break;
          
        } else{
          std::cout << "No Next Pixel." << std::endl;
          return EXIT_FAILURE;
        }
        
        break;

        case 3:
        std::cout << "State 3" << std::endl;

        //Successful Solution Found
        success = true;

        //Change the coordinates of solution to green
        std::cout << "Change To Green" << std::endl;
        input(currentSet[0], currentSet[1]) = GREEN;

        //Goal Met Create and Write to Output File
        writeToFile(input, argv[2]);

        break;

      }
      
    }

  } catch (std::exception &ex) {
    std::cout << "No Solution Found";
    std::cerr << ex.what() << std::endl;
    return EXIT_FAILURE;
  }
  
  std::cout << "Solution Found";
  return EXIT_SUCCESS;

}

bool inExplored(int input1, int input2){
  
  bool one = false;
  bool two = false;

  for(int i = 0; i < explored.size(); i++) {
    one = false;
    two = false;

    if(input1 == explored[i][0]){
      one = true;
    }
    if(input2 == explored[i][1]) {
      two == true;
    }

    if(one == true && two == true){
      return true;
    }
  }

  return false;
  
}

bool checkEdge(int input1, Image<Pixel> input) {
  if(input1 == 0) {
    return true;
  } else if (input1 == input.height()) {
    return true;
  } else if (input1 == input.width()) {
    return true;
  } else {
    return false;
  }
}