#define CATCH_CONFIG_MAIN
#include "catch.hpp"

#include "deque.hpp"


TEST_CASE( "Push Back", "Push Back" ) {

    Deque<int>* d;

    //Empty 
    REQUIRE(d->isEmpty());

    //Push Back
    d->pushBack(1);
    REQUIRE(d->back()==1);
    d->pushBack(2);
    REQUIRE(d->back()==2);
    d->pushBack(3);
    REQUIRE(d->back()==3);
}

TEST_CASE( "Push Front", "Push Front" ) {
    Deque<int>* d;
    //Push Front
    d->pushFront(3);
    REQUIRE(d->front()==1);
    d->pushFront(2);
    REQUIRE(d->front()==2);
    d->pushFront(1);
    REQUIRE(d->front()==3);

}

TEST_CASE( "Pop", "Pop" ) {
    Deque<int>* d;

    d->pushBack(1);
    d->pushBack(2);
    d->pushBack(3);
    d->pushFront(3);
    d->pushFront(2);
    d->pushFront(1);

    //Pop Back and Pop Front
    REQUIRE(d->front()==1);
    REQUIRE(d->back()==3);
    d->popBack();
    REQUIRE(d->front()==1);
    REQUIRE(d->back()==2);
    d->popFront();
    REQUIRE(d->front()==2);
    REQUIRE(d->back()==2);
    d->popBack();
    REQUIRE(d->front()==2);
    REQUIRE(d->back()==1);
    d->popFront();
    REQUIRE(d->front()==3);
    REQUIRE(d->back()==1);

    REQUIRE(d->isEmpty()==false);

    d->popFront();
    d->popBack();

    REQUIRE(d->isEmpty());


}
