#include "deque.hpp"
#include "image.h"

int main(int argc, char *argv[])
{
  // TODO
  //s = problem.initial()
  //Initial in the Red Pixal

  //if problem.goal(s) 
  //return (s)
  //Recolor red to green

  //frontier = a FIFO queue with s as the initial element
  //Boundary pixal is the goal state

  //explored = empty set

  //while true
  //if frontier is empty 
  //return failure

  //s = pop next state from frontier

  //add s to explored

  //for each state s_next in problem.actions(s) do
    //if s_next not in explored or frontier then
    //if problem.goal(s_next) then return s_next
    //insert s_next into the frontier
}
